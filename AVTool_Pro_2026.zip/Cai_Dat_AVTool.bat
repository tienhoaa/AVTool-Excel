@echo off
chcp 65001 >nul
title Cai Dat AVTool Pro - Microsoft Excel

echo ================================================================
echo        DANG CAI DAT AVTOOL PRO (DOI FONT, DVALUE & IN AN)...
echo ================================================================
echo.

:: Kiem tra xem nguoi dung da giai nen ra chua
if not exist "%~dp0TN_FontViet_Pro_2026.xlam" (
    echo [!] CHU Y: BAN CHUA GIAI NEN FILE ZIP!
    echo.
    echo Khong duoc chay truc tiep trong file nen ZIP.
    echo.
    echo HUONG DAN:
    echo 1. Nhap chuot phai vao file AVTool_Pro_2026.zip
    echo 2. Chon "Extract All..." (hoac "Extract to...")
    echo 3. Mo thu muc vua giai nen ra, roi nhap dup vao file Cai_Dat_AVTool.bat
    echo.
    echo ================================================================
    pause
    exit /b
)

:: 1. Tat Excel neu dang mo de tranh khoa file
taskkill /f /im excel.exe >nul 2>&1

:: 2. Xac dinh thu muc AddIns chuan cua Excel
set "TARGET_DIR=%APPDATA%\Microsoft\AddIns"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: 3. Xoa file cu trong XLSTART tranh bi trung 2 Tab
del /f /q "%APPDATA%\Microsoft\Excel\XLSTART\AVTool_FontViet.xlam" >nul 2>&1
del /f /q "%APPDATA%\Microsoft\Excel\XLSTART\TN_FontViet_Pro_2026.xlam" >nul 2>&1

:: 4. Copy file add-in, file xml va cac file xll ho tro IntelliSense vao thu muc AddIns
copy /y "%~dp0TN_FontViet_Pro_2026.xlam" "%TARGET_DIR%\TN_FontViet_Pro_2026.xlam" >nul
if exist "%~dp0TN_FontViet_Pro_2026.intellisense.xml" (
    copy /y "%~dp0TN_FontViet_Pro_2026.intellisense.xml" "%TARGET_DIR%\TN_FontViet_Pro_2026.intellisense.xml" >nul
)
if exist "%~dp0ExcelDna.IntelliSense.xll" (
    copy /y "%~dp0ExcelDna.IntelliSense.xll" "%TARGET_DIR%\ExcelDna.IntelliSense.xll" >nul
)
if exist "%~dp0ExcelDna.IntelliSense64.xll" (
    copy /y "%~dp0ExcelDna.IntelliSense64.xll" "%TARGET_DIR%\ExcelDna.IntelliSense64.xll" >nul
)
if exist "%~dp0Cap_Nhat_Online.bat" (
    copy /y "%~dp0Cap_Nhat_Online.bat" "%TARGET_DIR%\Cap_Nhat_Online.bat" >nul
)
if exist "%~dp0TN_KCAD_Mau_LamMoi_TCCS38.xlsx" (
    copy /y "%~dp0TN_KCAD_Mau_LamMoi_TCCS38.xlsx" "%TARGET_DIR%\TN_KCAD_Mau_LamMoi_TCCS38.xlsx" >nul
)
if exist "%~dp0TN_KCAD_Mau_TangCuong_MDCu.xlsx" (
    copy /y "%~dp0TN_KCAD_Mau_TangCuong_MDCu.xlsx" "%TARGET_DIR%\TN_KCAD_Mau_TangCuong_MDCu.xlsx" >nul
)

:: 5. Bo chan bao mat cua Windows (Unblock)
powershell -Command "Get-ChildItem -Path '%TARGET_DIR%' | Unblock-File -ErrorAction SilentlyContinue"

:: 6. Tu dong dang ky Addin vao Excel va cap quyen VBA Project
reg add "HKCU\Software\Microsoft\Office\16.0\Excel\Options" /v OPEN /t REG_SZ /d "\"%TARGET_DIR%\TN_FontViet_Pro_2026.xlam\"" /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\15.0\Excel\Options" /v OPEN /t REG_SZ /d "\"%TARGET_DIR%\TN_FontViet_Pro_2026.xlam\"" /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\14.0\Excel\Options" /v OPEN /t REG_SZ /d "\"%TARGET_DIR%\TN_FontViet_Pro_2026.xlam\"" /f >nul 2>&1

reg add "HKCU\Software\Microsoft\Office\16.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\15.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\14.0\Excel\Security" /v AccessVBOM /t REG_DWORD /d 1 /f >nul 2>&1

echo ================================================================
echo             [OK] DA CAI DAT THANH CONG 100%!
echo ================================================================
echo.
echo Tu bay gio:
echo  - Moi khi ban mo Excel, tren thanh menu se co ngay tab [AVTool].
echo  - Hop thoai nhac lenh trang tinh lo lung (IntelliSense) tu dong hoat dong khi go ham =Noisuy2b(, =NoisuyDay(, =NoisuyMatran(
echo  - Nut [Doi Font Tieng Viet]: Chuyen font TCVN3, VNI -> Unicode (Khong mat cong thuc).
echo  - Nut [Chen DValue Vao File]: Tinh khoi luong tu chu va tu hien Save As luu file .xls/.xlsm.
echo  - Nut [In Nhieu Sheet]: Form 2 cot chon sheet can in, doi thu tu va xem Print Preview.
echo  - Nut [Cap Nhat Ban Moi]: Kiem tra va cap nhat phien ban tu GitHub.
echo.
pause
